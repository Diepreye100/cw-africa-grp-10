const navLinkEl = document.getElementById("navLinks");

function showMenu() {
    navLinkEl.style.right = "0";
}
function hideMenu() {
    navLinkEl.style.right = "-200px";
}